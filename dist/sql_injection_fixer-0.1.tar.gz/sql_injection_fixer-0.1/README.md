# AutoFixer

A tool for automatically detecting and fixing popular python vulnerabilities such as SQL injection, eval() in Python code.

## Installing

```bash
pip install -r requirements.txt
python setup.py install
